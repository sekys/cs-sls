<?php
/*---------------------------------------------------+
| PHP-Fusion 6 Content Management System
+----------------------------------------------------+
| Copyright � 2002 - 2006 Nick Jones
| http://www.php-fusion.co.uk/
+----------------------------------------------------+
| Released under the terms & conditions of v2 of the
| GNU General Public License. For details refer to
| the included gpl.txt file or visit http://gnu.org
+----------------------------------------------------*/
require_once "maincore.php";
require_once "subheader.php";
require_once "side_left.php";
include LOCALE.LOCALESET."members-profile.php";
include LOCALE.LOCALESET."user_fields.php";

if (!isset($group_id)) {
	if (!isset($lookup) || !isNum($lookup)) fallback("index.php");
	$result = dbquery("SELECT * FROM ".$db_prefix."users WHERE user_id='$lookup'");
	if (dbrows($result)) { $data = dbarray($result); } else { redirect("index.php"); }
	opentable($locale['420']);
	echo "<table align='center' cellpadding='0' cellspacing='1' width='400' class='tbl-border'>
<tr>
<td colspan='3'>
<table align='center' cellpadding='0' cellspacing='0' width='100%'>
<tr>
<td class='tbl2'><b>".$data['user_name']."</b></td>
<td align='right' class='tbl2'>".getuserlevel($data['user_level'])."</td>
</tr>
</table>
</td>
<tr>
<td align='center' width='150' rowspan='5' class='tbl2'>\n";

	echo ($data['user_avatar'] ? "<img src='".IMAGES."avatars/".$data['user_avatar']."' alt='".$locale['u017']."'>" : $locale['u046'])."</td>
<td width='1%' class='tbl1' style='white-space:nowrap'><b>".$locale['u009']."</b></td>
<td class='tbl1'>".($data['user_location'] ? $data['user_location'] : $locale['u048'])."</td>
</tr>
<tr>
<td width='1%' class='tbl2' style='white-space:nowrap'><b>".$locale['u010']."</b></td>
<td class='tbl2'>";
	if ($data['user_birthdate'] != "0000-00-00") {
		$months = explode("|", $locale['months']);
		$user_birthdate = explode("-", $data['user_birthdate']);
		echo $months[number_format($user_birthdate['1'])]." ".number_format($user_birthdate['2'])." ".$user_birthdate['0'];
	} else {
		echo $locale['u048'];
	}
	echo "</td>
</tr>
<tr>
<td width='1%' class='tbl1' style='white-space:nowrap'><b>".$locale['u021']."</b></td>
<td class='tbl1'>".($data['user_aim'] ? $data['user_aim'] : $locale['u048'])."</td>
</tr>
<tr>
<td width='1%' class='tbl2' style='white-space:nowrap'><b>".$locale['u011']."</b></td>
<td class='tbl2'>".($data['user_icq'] ? $data['user_icq'] : $locale['u048'])."</td>
</tr>
<tr>
<td width='1%' class='tbl1' style='white-space:nowrap'><b>".$locale['u012']."</b></td>
<td class='tbl1'>".($data['user_msn'] ? $data['user_msn'] : $locale['u048'])."</td>
</tr>
<tr>
<td align='center' class='tbl1'>\n";
	if ($data['user_hide_email'] != "1" || iADMIN) {
		echo "[<a href='mailto:".str_replace("@","&#64;",$data['user_email'])."' title='".str_replace("@","&#64;",$data['user_email'])."'>".$locale['u051']."</a>]\n";
	}
	if ($data['user_web']) {
		$urlprefix = !strstr($data['user_web'], "http://") ? "http://" : "";
		echo "[<a href='".$urlprefix.$data['user_web']."' title='".$urlprefix.$data['user_web']."' target='_blank'>".$locale['u052']."</a>]\n";
	}
	if (!isset($userdata['user_id']) || $data['user_id'] != $userdata['user_id']) {
		echo "[<a href='messages.php?msg_send=".$data['user_id']."' title='".$locale['u060']."'>".$locale['u053']."</a>]\n";
	}
	echo "</td>
<td width='1%' class='tbl2' style='white-space:nowrap'><b>".$locale['u013']."</b></td>
<td class='tbl2'>".($data['user_yahoo'] ? $data['user_yahoo'] : $locale['u048'])."</td>
</tr>
</table>\n";

	tablebreak();
	

// Zaciatok ligy ....
$hodnost = array (	//Meno
	1 =>'Clan Leader', 
	'Z&aacute;stupca CL',
	'Spr&aacute;vca hr&aacute;&#269;ov',
	'Rusher',
	'Camper',
	'Skiller',
	'Sniper',	
	'Lama Clanu',
	'Hr&aacute;&#269'
);	
echo "<br>";		
	echo "<table align='center' cellpadding='0' cellspacing='1' width='400' class='tbl-border'>
		<tr>
			<td class='tbl2' colspan='2'><b>GeCom Cup Liga:</b></td>
		</tr>";
			if(!$data['cs_meno']) {
				echo "<tr><td width='1%' class='tbl1' style='white-space:nowrap' colspan='2'><b>Hr&aacute;&#269; nieje zapojen&yacute; do ligy ....</b></td></tr>";
			} else {	
			echo"<tr><td><table align='left' cellpadding='0' cellspacing='0' width='200'>			
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Hern&eacute; meno:</b></td>
							<td class='tbl2'><a href=\"/psychostats/index.php?q=".htmlentities($data['cs_meno'], ENT_QUOTES)."\" >".htmlentities($data['cs_meno'], ENT_QUOTES)."</a></td>
						</tr>";				
					echo"<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Clan:</b></td>
							<td class='tbl2'>"; 
							if($data['clan_id']) {														
								@$riadok=mysql_query("SELECT meno FROM `phpbanlist`.`acp_clans` WHERE id='".$data['clan_id']."'");			
								if(@mysql_num_rows($riadok)) {
									$riadok = mysql_fetch_array($riadok);
									echo '<a href="/cup/clan/'.$data['clan_id'].'/" >'.htmlentities($riadok['meno'], ENT_QUOTES).'</a>';
								} else {
									echo 'Clan nen&aacute;jden&yacute; .';
								}							
							} else {
								echo "na vo&#318;nej nohe.... "; 
							}					
						echo "</td>
						</tr>
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Hodnos&#357;:</b></td>
							<td class='tbl2'>";
							if($data['clan_id']) {											
								$pocet = count($hodnost);
								for($i=1; $i <= $pocet; $i++)
								{
									if($data['clan_hodnost'] == $i)
									{																	
										echo $hodnost[$i];
									}
								}
							}												
							echo "</td>					
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Posla&#357; pozv&aacute;nku:</b></td>
							<td class='tbl2'>
								<a href='/cup/pozvanku/".$data['user_name']."/'>
									<img src='/cup/styles/styles_web2/join.png' alt='Posla&#357; pozv&aacute;nku' title='Posla&#357; pozv&aacute;nku' border='0' align='absmiddle'>
								</a>										
							</td>
						</tr>	
				</table></td>	
				<td><table align='left' cellpadding='0' cellspacing='0' width='200'>
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Z&aacute;pasov:</b></td>
							<td class='tbl2'>";
								// Medzery oddeluju mena ....
								@$riadok=mysql_query("SELECT count(id) AS pocet FROM `phpbanlist`.`acp_zapas` WHERE 
													`ct_team`  LIKE '% ".$data['user_id']." %' OR 
													`t_team`  LIKE '% ".$data['user_id']." %' ");			
								$riadok = mysql_fetch_array($riadok);
								echo $riadok['pocet'];
							echo "</td>
						</tr>						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Zabit&yacute;ch:</b></td>
							<td class='tbl2'>".$data['cs_kill']."</td>
						</tr>						
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Smrti:</b></td>
							<td class='tbl2'>".$data['cs_death']."</td>
						</tr>	
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Hern&yacute; bonus:</b></td>
							<td class='tbl2'>".$data['cs_bonus']."%</td>
						</tr>																		
				</table></td></tr>";
			}	
	echo "</table>\n";	
	
	@$sql = mysql_query("SELECT uniqueid, rank, skill, activity, connections, kills, deaths, headshotkills, 	damage 
							FROM `psychostats`.`ps_plr` c
								LEFT JOIN ( SELECT plrid, connections, kills, deaths, headshotkills, damage FROM `psychostats`.`ps_plr_data` GROUP BY plrid ) z
								ON c.plrid = z.plrid							
							WHERE uniqueid LIKE '".$data['cs_meno']."'
						");
	$psychostats = mysql_fetch_array($sql);
	mysql_select_db("cstrike");
	
	echo "<table align='center' cellpadding='0' cellspacing='1' width='400' class='tbl-border'>
		<tr>
			<td class='tbl2' colspan='2'><b>Psychostats:</b></td>
		</tr>";
			if(!$psychostats['uniqueid']) {
				echo "<tr><td width='1%' class='tbl1' style='white-space:nowrap' colspan='2'><b>Psychostats z&aacute;znam nen&aacute;jden&yacute;.</b></td></tr>";
			} else {	
			echo"<tr><td><table align='left' cellpadding='0' cellspacing='0' width='200'>			
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Rank:</b></td>
							<td class='tbl2'>".$psychostats['rank']."</td>
						</tr>";				
					echo"<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Skill:</b></td>
							<td class='tbl2'>".$psychostats['skill']."</td>
						</tr>
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Aktivita:</b></td>
							<td class='tbl2'>".$psychostats['activity']."%</td>					
						</tr>				
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Pripojen&iacute;:</b></td>
							<td class='tbl2'>".$psychostats['connections']."</td>					
						</tr>
				</table></td>	
				<td><table align='left' cellpadding='0' cellspacing='0' width='200'>						
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Zabit&yacute;ch:</b></td>
							<td class='tbl2'>".$psychostats['kills']."</td>
						</tr>						
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Smrti:</b></td>
							<td class='tbl2'>".$psychostats['deaths']."</td>
						</tr>	
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Headshotov:</b></td>
							<td class='tbl2'>".$psychostats['headshotkills']."</td>
						</tr>						
						<tr>
							<td width='1%' class='tbl2' style='white-space:nowrap'><b>Damage:</b></td>
							<td class='tbl2'>".$psychostats['damage']."</td>
						</tr>																		
				</table></td></tr>";
			}	
	echo "</table>\n";
echo "<br>";	
// Koniec ligy ...

echo "<table align='center' cellpadding='0' cellspacing='1' width='400' class='tbl-border'>
<tr>
<td class='tbl2' colspan='2'><b>".$locale['422']."</b></td>
</tr>
<tr>
<td width='1%' class='tbl1' style='white-space:nowrap'><b>".$locale['u040']."</b></td>
<td class='tbl1'>".showdate("longdate", $data['user_joined'])."</td>
</tr>
<tr>
<td width='1%' class='tbl2' style='white-space:nowrap'><b>".$locale['u044']."</b></td>
<td class='tbl2'>".($data['user_lastvisit'] != 0 ? showdate("longdate", $data['user_lastvisit']) : $locale['u049'])."</td>
</tr>
<tr>
<td width='1%' class='tbl1' style='white-space:nowrap'><b>".$locale['u041']."</b></td>
<td class='tbl1'>".number_format(dbcount("(shout_id)", "shoutbox", "shout_name='".$data['user_id']."'"))."</td>
</tr>
<tr>
<td width='1%' class='tbl2' style='white-space:nowrap'><b>".$locale['u042']."</b></td>
<td class='tbl2'>".number_format(dbcount("(comment_id)", "comments", "comment_name='".$data['user_id']."'"))."</td>
</tr>
<tr>
<td width='1%' class='tbl1' style='white-space:nowrap'><b>".$locale['u043']."</b></td>
<td class='tbl1'>".number_format($data['user_posts'])."</td>
</tr>
</table>\n";
	
	
	
	
	if ($data['user_groups']) {
		tablebreak();
		echo "<table align='center' cellpadding='0' cellspacing='1' width='400' class='tbl-border'>\n";
		echo "<tr>\n<td class='tbl2'><b>".$locale['423']."</b></td>\n\n</tr>\n<tr>\n<td class='tbl1'>\n";
		$user_groups = (strpos($data['user_groups'], ".") == 0 ? explode(".", substr($data['user_groups'], 1)) : explode(".", $data['user_groups']));
		for ($i = 0;$i < count($user_groups);$i++) {
			echo "<a href='".FUSION_SELF."?group_id=".$user_groups[$i]."'>".getgroupname($user_groups[$i])."</a>";
			if ($i != (count($user_groups)-1)) { echo ",\n"; } else { echo "\n"; }
		}
		echo "</td>\n</tr>\n</table>\n";
	}
} else {
	if (!isNum($group_id)) fallback("index.php");
	$result = dbquery("SELECT * FROM ".$db_prefix."user_groups WHERE group_id='$group_id'");
	if (dbrows($result)) {
		$data = dbarray($result);
		$result = dbquery("SELECT * FROM ".$db_prefix."users WHERE user_groups REGEXP('^\\\.{$group_id}$|\\\.{$group_id}\\\.|\\\.{$group_id}$') ORDER BY user_level DESC, user_name");
		opentable($locale['410']);
		echo "<table align='center' cellpadding='0' cellspacing='1' width='100%' class='tbl-border'>
<tr>
<td align='center' colspan='2' class='tbl1'><b>".$data['group_name']."</b> (".sprintf((dbrows($result)==1?$locale['411']:$locale['412']), dbrows($result)).")</td>
</tr>
<tr>
<td class='tbl2'><b>".$locale['401']."</b></td>
<td align='center' width='1%' class='tbl2' style='white-space:nowrap'><b>".$locale['402']."</b></td>
</tr>\n";
		while ($data = dbarray($result)) {
			$cell_color = ($i % 2 == 0 ? "tbl1" : "tbl2"); $i++;
			echo "<tr>\n<td class='$cell_color'>\n<a href='profile.php?lookup=".$data['user_id']."'>".$data['user_name']."</a></td>\n";
			echo "<td align='center' width='1%' class='$cell_color' style='white-space:nowrap'>".getuserlevel($data['user_level'])."</td>\n</tr>";
		}
		echo "</table>\n";
	} else {
		fallback(BASEDIR."index.php");
	}
}
closetable();

require_once "side_right.php";
require_once "footer.php";
?>