<?php
if (!defined("IN_FUSION")) { header("Location: ../../index.php"); exit; }
require_once INCLUDES."theme_functions_include.php";
include_once BASEDIR."config.php";

//===========================================================================================================================
// iMEMBER

function render_header($header_content) {
	global $theme_width;
	require_once THEME."inc/status.php";
	
echo '
	<script type="text/javascript" src="http://www.cs.gecom.sk/themes/seky_web2/inc/jquery.js"></script>

<div id="header" >
	<div id="colum" >
		<div id="banner" >
		<div id="ads"> </div>
		<div >
		<embed src="http://www.cs.gecom.sk/themes/seky_web2/inc/imagerotator.swf" width="635" height="90" hspace="0" style="" flashvars="transition=flash&file=http://www.cs.gecom.sk/themes/seky_web2/inc/banner.xml&width=560&height=90&searchbar=false&backcolor=0xFFFFFF&showicons=false&shownavigation=false&usefullscreen=false&linkfromdisplay=true" allowfullscreen="true" quality="high" name="rotator" id="rotator" type="application/x-shockwave-flash"/>
		</div>	
		</div>	
		<div id="page-panel" >';	
// 	<a href=http://www.cs.gecom.sk/images/ppu.jpg> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu12.png border='0' align='absmiddle'/> N&aacute;vod na &scaron;ek</a> 

		echo "<div id=chromemenu>				
				<h2 onMouseover=cssdropdown.dropit(this,event,'dropmenu2') ><a class=menu href=http://www.cs.gecom.sk/news.php >Port&aacute;l</a></h2>
				<h2 onMouseover=cssdropdown.dropit(this,event,'dropmenu3') ><a class=menu href=http://www.cs.gecom.sk/viewpage.php?page_id=5 >Vip &uacute;&#269;et</a></h2>
				<h2 onMouseover=cssdropdown.dropit(this,event,'dropmenu4') ><a class=menu href=http://www.cs.gecom.sk//cup.php >GeCom Cup</a></h2>
				<h2 onMouseover=cssdropdown.dropit(this,event,'dropmenu5') ><a class=menu href=http://www.cs.gecom.sk/forum/index.php >Komunita</a></h2>
				<h2 onMouseover=cssdropdown.dropit(this,event,'dropmenu6') ><a class=menu href='http://www.gecom.sk/' >GeCom s.r.o.</a></h2>
				
				<div id=dropmenu2 class=dropmenudiv>
					<a href=http://www.cs.gecom.sk/news.php > <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu22.png border='0' align='absmiddle'/> Home</a>
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=23 > <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu19.png border='0' align='absmiddle'/> Admin-team</a>
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=3> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu16.png border='0' align='absmiddle'/> Pravidl&aacute;</a>
					<a href=http://www.cs.gecom.sk/ban/ban_list.php> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu3.png border='0' align='absmiddle'/> Ban list</a>
					<a href=http://www.cs.gecom.sk/psychostats/> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu13.png border='0' align='absmiddle'/> Psychostats</a>
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=31> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu11.png border='0' align='absmiddle'/> Server status</a>
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=37> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu2.png border='0' align='absmiddle'/> Podporte n&aacute;s</a>
				</div>			
				<div id=dropmenu3 class=dropmenudiv> 
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=5> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu10.png border='0' align='absmiddle'/> Aktiv&aacute;cia + v&yacute;hody</a> 
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=71> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu24.png border='0' align='absmiddle'/> Zombie body </a> 
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=43> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu15.png border='0' align='absmiddle'/> U&#382;&iacute;vatelia</a> 
				</div>				
				<div id=dropmenu4 class=dropmenudiv>
					<a style='border-bottom: 1px solid #000;' href=http://www.cs.gecom.sk/cup.php?cup_create_clan=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu6.png border='0' align='absmiddle'/> Vytvori&#357; clan</a>  
					<a href=http://www.cs.gecom.sk/cup.php?cup_edit_clan=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu5.png border='0' align='absmiddle'/> Nastavenia</a>  
					<a href=http://www.cs.gecom.sk/cup.php?cup_edit_players=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu19.png border='0' align='absmiddle'/> Spr&aacute;va hr&aacute;&#269;ov</a>  
					<a href=http://www.cs.gecom.sk/cup.php?cup_zoznam_vyzva=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu20.png border='0' align='absmiddle'/> V&yacute;zvy a ponuky</a> 
					<a href=http://www.cs.gecom.sk/cup.php?cup_edit_vyzvy=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu4.png border='0' align='absmiddle'/> Moje v&yacute;zvy </a>  	 
					<a style='border-top: 1px solid #000;' href=http://www.cs.gecom.sk/cup.php?cup_hraci_tabulka=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu23.png border='0' align='absmiddle'/> Vo&#318;n&eacute; miesta </a>  
					<a href=http://www.cs.gecom.sk/cup.php?cup_zoznam_zapasy=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu21.png border='0' align='absmiddle'/> Najbli&#382;&scaron;ie z&aacute;pasy </a>  
					<a href=http://www.cs.gecom.sk/cup.php?cup_history=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/cs_small.gif height='16' width='16' border='0' align='absmiddle'/> Hist&oacute;ria z&aacute;pasov </a>  
					<a href=http://www.cs.gecom.sk/cup.php?cup_rank_tabulka=true> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu10.png border='0' align='absmiddle'/> Score Tabu&#318;ka</a>
					<a href=http://www.cs.gecom.sk/cup.php> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu18.png border='0' align='absmiddle'/> GeCom Cup liga</a>
				</div>
				<div id=dropmenu5 class=dropmenudiv> 
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=53> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu14.png border='0' align='absmiddle'/> &#381;iados&#357; o unban</a>
					<a href=http://www.cs.gecom.sk/data.php?mode=connect> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu1.png border='0' align='absmiddle'/> Ako sa pripoji&#357; ?</a>
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=47> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu7.png border='0' align='absmiddle'/> N&aacute;vody</a> 
					<a href=http://www.cs.gecom.sk/forum/index.php> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu9.png border='0' align='absmiddle'/> F&oacute;rum</a> 
					<a href=http://www.cs.gecom.sk/viewpage.php?page_id=49> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu8.png border='0' align='absmiddle'/> Download</a> 
					<a href=http://www.cs.gecom.sk/search.php> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/menu17.png border='0' align='absmiddle'/> H&#318;ada&#357;</a> 
				</div>
				<div id=dropmenu6 class=dropmenudiv>
					<a href='http://www.gecom.sk/'> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/logo.png border='0' align='absmiddle'/> GeCom s. r. o.</a>
					<a href='http://www.gecom.sk/meteo/'> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/logo.png border='0' align='absmiddle'/> Po&#269;asie Michalovce</a>
					<a href='http://portal.gecom.sk/login.php'> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/logo.png border='0' align='absmiddle'/> GeCom port&aacute;l</a>
					<a href='http://eshop.gecom.sk/'> <img src=http://www.cs.gecom.sk/themes/seky_web2/img/menu/logo.png border='0' align='absmiddle'/> eShop GeCom</a>
				</div>	
			</div>			
		</div>	
		<div id='header-logo'></div>
		<div id='status' align='left'>
		<ul>
			<li id='m1' class='modra' onmouseout=this.className='modra' onmouseover=this.className='cervena' >Live Status</li>
			<li id='m2' class='modra' onmouseout=this.className='modra' onmouseover=this.className='cervena' >V&yacute;zvy</li>
		</ul>	
		</div>
<div class='menu1'>
	<div class='menu2'>
	<div id='stats-1' class='normal'>
		<table width='275' id='stats' cellpadding='0' cellspacing='0'>
		  <tr >";
		  
		$server = server();
		$temp = "onmouseover=this.style.backgroundImage='url(http://www.cs.gecom.sk/themes/seky_web2/img/server2.gif)' onmouseout=this.style.backgroundImage='url(http://www.cs.gecom.sk/themes/seky_web2/img/server.gif)'";  
	echo "	 
		 <td ".$temp." ><div class='servername'>Server</div><div class='info'><h4>".$server[0]."</h4></div></td>
		  </tr>
		  <tr >
		     <td ".$temp." ><div class='servername'>IP Adresa</div><span class='info'><a href='www'><h4>".$server[1]."<h4></a></span></td>
		  </tr>
		  <tr >
		     <td ".$temp." ><div class='servername'>Hr&aacute;&#269;ov</div><div class='info'>".$server[2]."</div></td>
		  </tr>
		  <tr >
		     <td ".$temp." ><div class='servername'>Mapa</div><div class='info'>".$server[3]."</div></td>	
		  </tr>					
		<tr>
		     <td ".$temp." ><div class='servername'>Timeleft</div><div class='info'><span id='cas'>".$server[4]."</span></div></td>
		  </tr>
		</table>
	</div>
</div>
	<div id='logo' >
		  <div align='center' ><h1><a href='http://www.cs.gecom.sk/'><img src=http://www.cs.gecom.sk/themes/seky_web2/img/logo.png alt='GeCom::Lekos CS 1.6' title='GeCom::Lekos CS 1.6' border='0' /></a> </h1></div>
		</div>
</div>
	<div class='menu3' id='players' >		
	";
	
	$cesta = '/cup.php';
	@$sql_vyzva = mysql_query("SELECT id, ziada, datum, hodina FROM `phpbanlist`.`acp_vyzva` WHERE prijal IS NULL AND sukromna = 0 ORDER BY datum LIMIT 15");
	$pocet = @mysql_num_rows($sql_vyzva);
	
	if($pocet)
	{
		$i=0;
		$pocet = $pocet - 1;

		$temp = "onmouseover=this.style.backgroundImage='url(http://www.cs.gecom.sk/themes/seky_web2/img/stats-li2.gif)' onmouseout=this.style.backgroundImage='url(http://www.cs.gecom.sk/themes/seky_web2/img/stats-li.gif)'";
		
		while($vyzva=mysql_fetch_assoc($sql_vyzva)) 
		{ 
			@$sql_clan=mysql_query("SELECT meno,narod FROM `phpbanlist`.`acp_clans` WHERE id ='".$vyzva['ziada']."'");
			$clan=mysql_fetch_assoc($sql_clan);
			
			if(!$clan['meno'])
			{
				$clan['meno'] = '???';
			}
				//echo '<!--'.$i.'-'.$pocet.'-'.mysql_num_rows($sql_vyzva).'-->';
					//Start skupiny
					if(($i==0) or ($i==5) or ($i==10) or ($i==15) or ($i==20) or ($i==25) or ($i==30)) { 
					echo '<div class="message"><table width="275" border="0" cellpadding="0" cellspacing="0">'; 
					}
						echo ' <tr id=P-' . $i .'><td class="vyzva_ok" id="vyzva" '.$temp.'><table cellpadding="0" cellspacing="0" border="0" class="playername"><tr>
									<td><a href="'.$cesta.'?cup_info_clan='.$vyzva['ziada'].'"><img src="/cup/images/vlajka_'.$clan['narod'].'.gif" alt="N&aacute;rodnos&#357; clanu" title="N&aacute;rodnos&#357; clanu"border="0" align="absmiddle"> '.htmlspecialchars($clan['meno'], ENT_QUOTES).'</a></td>
									<td align="right">'.$vyzva['datum'].':'.$vyzva['hodina'].' <a href="'.$cesta.'?cup_prijat_vyzvu='.$vyzva['id'].'"> <img height="16" width="16" border="0" title="Prijat" src="/cup/images/cup_ok.gif" align="absmiddle" /> </a> </td>
								</tr></table></td></tr>';			
					
					//Ak je pocet hracov nieje v nasobku 5 ,ukonci necelu skupinu a dalej nepokracuje
					if( $i == $pocet ) { 
						echo '</table></div>';
					} else { 
						//Ukoncuje skupinu
						if(($i==4) or ($i==9) or ($i==14) or ($i==19) or ($i==24) or ($i==29)){
						echo '</table></div>'; 
						}
					}
				$i++;			
		}
	}	else {
	  echo '<div class="message">
				<table width="275" border="0" ">
					<tr>
						<td class="vyzva_eror" id="vyzva">
							<div class="playername">&#381;iadne v&yacute;zvy ...</div>
						</td>
					</tr>
				</table>
			</div>';
	}

		
echo "							
	</div>		
</div>
</div>

<div  id='panel2' >
	<div id='colum' >	
	<div >";
	
	if (!iMEMBER) {
		echo "<li class='modra' onmouseout=this.className='modra' onmouseover=this.className='cervena' >Vitaj <span class='meno'>Hos&#357;</span> ,pros&iacute;m <a href='#login' onclick='prihlasit()'>prihlas</a> sa . </li>";
	} else { 
		echo "<li class='modra' onmouseout=this.className='modra' onmouseover=this.className='cervena' >Vitaj <span class='meno'>".$userdata['user_name']."</span> ,n&aacute;js&#357;<a href='http://www.cs.gecom.sk/cup.php?cup_hraci_tabulka=true'>clan</a> . </li>";
	} 
echo "<li class='modra' id='server' >".$server[0]."</li>

	</div>
	</div>
</div>
";
echo '
<script type="text/javascript" src="http://www.cs.gecom.sk/themes/seky_web2/inc/engine.js"></script>
<script language="JavaScript">
	function casovac() { ';
	if( $server[5] == true )	
	{	
		echo '
		nextmap = "'.$server[4].'";
		if( nextmap < 0)
		{
			document.getElementById("cas").innerHTML=("-"); 
		}	else {
			cmin2=1*Minutes(nextmap); 
			csec2=0+Seconds(nextmap); 
			DownRepeat(); 
		}';
	}	
echo '}
	casovac();
</script>
<div id="stred" >
	<div id="colum">
		<table width="800" border="0" id="artikles" cellpadding="0" cellspacing="0"> 
			<tr>
				<td>';

}

function render_footer($license=false) 
{
echo "
				</td>";
	/*
http://www.iconarchive.com/category/folder/leox-graphite-icons-by-icontoaster.html

	*/
echo "	
			</tr>
		</table>	
	</div>
</div>



<div id='footer' >
	<div id='colum' >
	<div id='credits' >&copy; 2009 <a href='http://www.gecom.sk/'>GeCom</a>::<a href='http://www.lekosonline.sk/'>Lekos</a><br /><a href='http://seky.tym.sk/'>Design & Code by Seky</a></div>
	<div id='footer-ads' align='center'>
		<h1><a href='http://www.cs.gecom.sk/psychostats/'>Psychostats</a></h1> | <h1><a href='http://www.cs.gecom.sk/acp/login.php'>ACP</a></h1> | <h1><a href='http://www.cs.gecom.sk/ban/'>Ban list</a></h1>
		<br>
		<br>
		Powered by <a href='http://www.php-fusion.co.uk'>PHP-Fusion</a> copyright &copy; 2002 - 2009 by Nick Jones.
		Released as free software without warranties under <a href='http://www.fsf.org/licensing/licenses/agpl-3.0.html'>GNU Affero GPL</a>
		</div>
	</div>
</div>";
	//echo ' <embed type="application/x-mplayer2" pluginspage="http://www.microsoft.com/Windows/MediaPlayer/" name="mediaplayer1" showstatusbar="1" EnableContextMenu="false" autostart="true" width="0" height="0"  transparentstart="1" loop="0" controller="true" src="'.BASEDIR.''.THEME.'inc/load.mp3"></embed>	';
}

//===========================================================================================================================

		
	/*	
		
		
		
		
		
		// Rank
		$rank=0;
		@$sql=mysql_query("SELECT id,meno,avatar,bodov,narod FROM `phpbanlist`.`acp_clans` ORDER BY bodov desc LIMIT 7");

		while($row=mysql_fetch_assoc($sql)) 
		{ 
			$rank++; 
				echo '		<tr>
								<td width="310">
									<img src="/cup/images/vlajka_'.$row['narod'].'.gif" alt="N&aacute;rodnos&#357; clanu" title="N&aacute;rodnos&#357; clanu"border="0" align="absmiddle">
									<img src="'.( $row['avatar'] ? $row['avatar'] : '/images/liga/no_avatar.jpg' ).'" width="13" height="9"/>
									<b>'.$rank.'.</b> <a href="'.$cesta.'?cup_info_clan='.$row['id'].'">'.htmlspecialchars($row['meno'], ENT_QUOTES).'</a>
								</td>
								<td>
									<img src="/themes/er2_gecom/images/cs16.gif"/><span style="color: yellow;"> '.$row["bodov"].' </span> 
									<a href="'.$cesta.'?cup_poslat_vyzvu='.$row["id"].'"><img height="10" width="10" border="0" title="Vyzvat" src="/themes/er2_gecom/images/vyzvat.gif"/></a>
								</td>
							</tr>';
		}
		mysql_select_db("cstrike");
	*/	
		

function dbin($query) {
	$result = @mysql_query($query);
	if (!$result) {
		echo mysql_error();
		return false;
	} else {
		return $result;
	}
}
function naujienos($info,$sep="",$class="") {
	$res = "Autor: <a href='profile.php?lookup=".$info['user_id']."' >".$info['user_name']."</a>&nbsp;&nbsp;";
	//$res .= $info['news_ext'] == "y" || $info['news_allow_comments'] ? "\n" : "\n";
	return $res;
}
function papildomi($info,$sep="",$class="") {
	global $locale; 
	if (!isset($_GET['readmore']) && $info['news_ext'] == "y") $res = "<a href='news.php?readmore=".$info['news_id']."' >".$locale['042']."</a>&nbsp;&nbsp;";
	if ($info['news_allow_comments']) $res .= "<a href='news.php?readmore=".$info['news_id']."' >".$info['news_comments'].$locale['043']."</a>&nbsp;&nbsp;";
	if ($info['news_ext'] == "y" || $info['news_allow_comments']) 
	$res .= " <a href='print.php?type=N&amp;item_id=".$info['news_id']."' target=_blank>".$locale['045']."</a>\n";
	return $res;
}

function render_news($subject, $news, $info) {
	echo '
				<div id="clanok'.$info['news_id'].'" class="clanok">
				<div class="clanok-header"><h3 id="clanok-name">'.$subject.'</h3><span id="date">'.showdate("longdate", $info['news_date']).'</span></div>
				<div class="clanok-colum" align="left"><h5>
				'.$news.'
				</h5>';
				//<span id="clanok-'.$info['news_id'].'-dalej" class="hidden">'.$info['news_extended'].'<br>'.naujienos($info).''.papildomi($info).'</span>';						
	echo "		<div class=clanok-footer >
					<a onmouseout=this.style.color='#999999' onmouseover=this.style.color='#2f8bac' id=clanok-".$info['news_id']."-tlacitko href='news.php?readmore=".$info['news_id']."' >
					<img src=http://www.cs.gecom.sk/themes/seky_web2/img/pokracovat.gif border=0 /> &#268;&iacute;ta&#357; &#271;alej ...</a></div>
				</div>
			</div>
	";		
}

function render_article($subject, $article, $info) {
	
echo "<table width='100%' cellpadding='0' cellspacing='0'>
<tr>
<td class='capmain'>$subject</td>
</tr>
<tr>
<td class='main-body'>
".($info['article_breaks'] == "y" ? nl2br($article) : $article)."
</td>
</tr>
<tr>
<td align='center' class='news-footer'>\n";
echo openform("A",$info['article_id']).articleposter($info," &middot;").articleopts($info,"&middot;").closeform("A",$info['article_id']);
echo "</td>
</tr>
</table>\n";

}

function opentable($title) {

echo "<table cellpadding='0' cellspacing='0' width='100%'>
<tr>
<td class='capmain'>$title</td>
</tr>
<tr><td width=100% ></td></tr>
<tr>
<td class='main-body'>\n";

}

function closetable() {
	echo "</td>
	</tr>
	</table>\n";
}

function openside($title) {
	echo "<table cellpadding='0' cellspacing='0' width='100%'>
	<tr>
	<td class='scapmain'>$title</td>
	</tr>
	<tr><td width=100%></td></tr>
	<tr>
	<td class='side-body'>\n";
}
function openside_2($title) {
	echo " <div id='profil-head' align='center' >$title</div> ";
}
function closeside() {
	echo "
	</td>
	</tr>
	</table>\n";
}


function opensidex($title,$state="on") {
	$boxname = str_replace(" ", "", $title);
	echo "<table cellpadding='0' cellspacing='0' width='100%' class='border'>
	<tr>
	<td class='scapmain'>$title</td>
	<td class='scapmain' align='right'>".panelbutton($state,$boxname)."</td>
	</tr>
	<tr><td colspan=2 width=100% height=1 background=http://www.cs.gecom.sk/themes/seky_web2/images/dotted2.gif></td></tr>
	<tr>
	<td colspan='2' class='side-body'>
	<div id='box_$boxname'".($state=="off"?" style='display:none'":"").">\n";
}

function closesidex() {
echo "</div>
</td>
</tr>
</table>\n";
tablebreak();
}

function tablebreak() {
echo "<table cellpadding='0' cellspacing='0' width='100%'>\n<tr>\n<td height='5'></td>\n</tr>\n</table>\n";
}
?>