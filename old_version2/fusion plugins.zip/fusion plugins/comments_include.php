<?php
/*---------------------------------------------------+
| PHP-Fusion 6 Content Management System
+----------------------------------------------------+
| Copyright � 2002 - 2005 Nick Jones
| http://www.php-fusion.co.uk/
+----------------------------------------------------+
| Released under the terms & conditions of v2 of the
| GNU General Public License. For details refer to
| the included gpl.txt file or visit http://gnu.org
+----------------------------------------------------+
| Comments system developed by CrappoMan
| email: simonpatterson@dsl.pipex.com
+----------------------------------------------------*/
if (!defined("IN_FUSION")) { header("Location:../index.php"); exit; }

include LOCALE.LOCALESET."comments.php";

function showcomments($ctype,$cdb,$ccol,$cid,$clink) {

	global $settings,$locale,$userdata,$db_prefix;
	
	if ((iMEMBER || $settings['guestposts'] == "1") && isset($_POST['post_comment'])) {
		$flood = false;
		if($cdb == true) {	
			if (dbrows(dbquery("SELECT $ccol FROM ".DB_PREFIX."$cdb WHERE $ccol='$cid'"))==0) {
				fallback(BASEDIR."index.php");
			}
		}	
		if (iMEMBER) {
			$comment_name = $userdata['user_id'];
		} elseif ($settings['guestposts'] == "1") {
			$comment_name = trim(stripinput($_POST['comment_name']));
			$comment_name = preg_replace("(^[0-9]*)", "", $comment_name);
			if (isNum($comment_name)) $comment_name="";
		}
		$comment_message = trim(stripinput(censorwords($_POST['comment_message'])));
		$comment_smileys = isset($_POST['disable_smileys']) ? "0" : "1";
		if ($comment_name != "" && $comment_message != "" && !preg_match("#\[url\](.*?)\[/url\]#si", $message)) {
			$result = dbquery("SELECT MAX(comment_datestamp) AS last_comment FROM ".DB_PREFIX."comments WHERE comment_ip='".USER_IP."'");
			if (!iSUPERADMIN || dbrows($result) > 0) {
				$data = dbarray($result);
				if ((time() - $data['last_comment']) < $settings['flood_interval']) {
					$flood = true;
					$result = dbquery("INSERT INTO ".DB_PREFIX."flood_control (flood_ip, flood_timestamp) VALUES ('".USER_IP."', '".time()."')");
					if (dbcount("(flood_ip)", "flood_control", "flood_ip='".USER_IP."'") > 4) {
						if (iMEMBER) $result = dbquery("UPDATE ".DB_PREFIX."users SET user_status='1' WHERE user_id='".$userdata['user_id']."'");
					}
				}
			}
			if (!$flood) $result = dbquery("INSERT INTO ".DB_PREFIX."comments (comment_item_id, comment_type, comment_name, comment_message, comment_smileys, comment_datestamp, comment_ip) VALUES ('$cid', '$ctype', '$comment_name', '$comment_message', '$comment_smileys', '".time()."', '".USER_IP."')");
		}
		redirect($clink);
	}




	tablebreak();
	opentable($locale['c100']);
	$result = dbquery(
		"SELECT tcm.*,user_name,user_avatar,user_groups FROM ".DB_PREFIX."comments tcm
		LEFT JOIN ".DB_PREFIX."users tcu ON tcm.comment_name=tcu.user_id
		WHERE comment_item_id='$cid' AND comment_type='$ctype'
		ORDER BY comment_datestamp ASC"
	);
	if (dbrows($result) != 0) {
		$i = 0;
		echo "<table width='100%' cellpadding='0' cellspacing='1' class='tbl-border'>\n";
		while ($data = dbarray($result)) {

			if ($data['user_avatar'] != "") {
				$avatar = "<a href='".BASEDIR."profile.php?lookup=".$data['comment_name']."'><img height='100' width='100' src='".IMAGES."avatars/".$data['user_avatar']."' style='border : 1px solid #fdef0f;'></a>";
			} else {
				$avatar = "<a href='".BASEDIR."profile.php?lookup=".$data['comment_name']."'><img height='100' width='100' src='/infusions/user_info_panel/images/noimage.png' style='border : 1px solid #fdef0f;'></a>";
			}
			echo "<tr><td width='100' class='".($i% 2==0?"tbl1":"tbl2")."'>".$avatar."</td>\n<td  class='".($i% 2==0?"tbl1":"tbl2")."'  valign='top'><span style='color:black'>\n";
			if ($data['user_name']) {
				echo " <table width='100%' width='15'  cellpadding='0' cellspacing='1' class='comments'><tr><td valign='top'></span><b> <a href='".BASEDIR."profile.php?lookup=".$data['comment_name']."'>".$data['user_name']."</a></b>$imranks";
			} else {
				echo $data['comment_name'];
			}
			if ($data['comment_smileys'] == "1") {
				$comment_message = parsesmileys($data['comment_message']);
			} else {
				$comment_message = $data['comment_message'];
			}
			$comment_message = nl2br(parseubb($comment_message));
			echo "</span>\n<span class='small'>".$locale['041'].showdate("longdate", $data['comment_datestamp'])."</span></td></tr></table></b>\n";
			echo $comment_message."</td>\n</tr>\n";
			$i++;
		}
		if (checkrights("C")) echo "<tr>\n<td colspan='2' align='right' class='".($i% 2==0?"tbl1":"tbl2")."'><a href='".ADMIN."comments.php?ctype=$ctype&cid=$cid'>".$locale['c106']."</a></td>\n</tr>\n";
		echo "</table>\n";
	} else {
		echo $locale['c101']."\n";
	}
	closetable();
	tablebreak();
// Calculate random equation and answer
$var1 = rand(1,5);
$var2 = rand(1,5);
$equation = $var1 . " + " . $var2 . "=";
$validation_answer = $var1 + $var2;
	opentable($locale['c102']);
	if (iMEMBER || $settings['guestposts'] == "1") {
		echo "<form name='inputform' method='post' action='$clink'>
<table align='center' cellspacing='0' cellpadding='0' class='tbl'>\n";
		if (iGUEST) {
			echo "<tr>
<td>".$locale['c103']."</td>
</tr>
<tr>
<td><input type='text' name='comment_name' maxlength='50' class='textbox' style='width:100%;'></td>
</tr>\n";
		}
		echo "<tr>
<td align='center'><textarea name='comment_message' rows='6' class='textbox' style='width:400px'></textarea><br>
".displaysmileys("comment_message")."
</td></tr>
<tr>
<td align='center'>
<br><input type='submit' name='post_comment' value='".$locale['c102']."' class='button'><br></td>
</tr>
</table>
</form>\n";
	} else {
		echo $locale['c105']."\n";
	}
	closetable();
}
?>